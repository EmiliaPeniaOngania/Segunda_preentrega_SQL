CREATE DATABASE  IF NOT EXISTS `ent_fciera` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ent_fciera`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: ent_fciera
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `vw_resumen_tablon`
--

DROP TABLE IF EXISTS `vw_resumen_tablon`;
/*!50001 DROP VIEW IF EXISTS `vw_resumen_tablon`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_resumen_tablon` AS SELECT 
 1 AS `FECHA_PROCESO`,
 1 AS `NOMBRE_PRODUCTO`,
 1 AS `round(count(t.N_PRESTAMO),0)`,
 1 AS `round(sum(t.DEUDA_CAPITAL),2)`,
 1 AS `round(sum(t.DEUDA_INTERES),2)`,
 1 AS `round(sum(t.DEUDA_IVA),2)`,
 1 AS `round(sum(t.DEUDA_TOTAL),2)`,
 1 AS `round(sum(t.CARGO_INCOB),2)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_costo_prestamos`
--

DROP TABLE IF EXISTS `vw_costo_prestamos`;
/*!50001 DROP VIEW IF EXISTS `vw_costo_prestamos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_costo_prestamos` AS SELECT 
 1 AS `PERIODO`,
 1 AS `N_PRESTAMO`,
 1 AS `NOMBRE_PRODUCTO`,
 1 AS `COSTO`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_tablon`
--

DROP TABLE IF EXISTS `vw_tablon`;
/*!50001 DROP VIEW IF EXISTS `vw_tablon`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_tablon` AS SELECT 
 1 AS `FECHA_PROCESO`,
 1 AS `N_PRESTAMO`,
 1 AS `NOMBRE_PRODUCTO`,
 1 AS `FECHA_LIQUIDACION`,
 1 AS `PLAZO`,
 1 AS `TNA`,
 1 AS `CAP_FINANCIADO`,
 1 AS `DEUDA_CAPITAL`,
 1 AS `DEUDA_INTERES`,
 1 AS `DEUDA_IVA`,
 1 AS `DEUDA_TOTAL`,
 1 AS `ATRASO`,
 1 AS `CARGO_INCOB`,
 1 AS `PERIODO_COSTO`,
 1 AS `COSTO`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_int_devengado`
--

DROP TABLE IF EXISTS `vw_int_devengado`;
/*!50001 DROP VIEW IF EXISTS `vw_int_devengado`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_int_devengado` AS SELECT 
 1 AS `FECHA_PROCESO`,
 1 AS `N_PRESTAMO`,
 1 AS `N_CUOTA`,
 1 AS `F_INICIO`,
 1 AS `F_VTO`,
 1 AS `F_PAGO`,
 1 AS `CAPITAL`,
 1 AS `INT_DEV`,
 1 AS `IVA_DEV`,
 1 AS `ESTADO_CUOTA`,
 1 AS `ATRASO_CUOTA`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_detalle_pagos`
--

DROP TABLE IF EXISTS `vw_detalle_pagos`;
/*!50001 DROP VIEW IF EXISTS `vw_detalle_pagos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_detalle_pagos` AS SELECT 
 1 AS `N_PRESTAMO`,
 1 AS `N_CUOTA`,
 1 AS `F_VTO`,
 1 AS `CAPITAL`,
 1 AS `INTERES`,
 1 AS `IVA`,
 1 AS `F_PAGO`,
 1 AS `IMPORTE`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vw_resumen_tablon`
--

/*!50001 DROP VIEW IF EXISTS `vw_resumen_tablon`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_resumen_tablon` AS select `t`.`FECHA_PROCESO` AS `FECHA_PROCESO`,`t`.`NOMBRE_PRODUCTO` AS `NOMBRE_PRODUCTO`,round(count(`t`.`N_PRESTAMO`),0) AS `round(count(t.N_PRESTAMO),0)`,round(sum(`t`.`DEUDA_CAPITAL`),2) AS `round(sum(t.DEUDA_CAPITAL),2)`,round(sum(`t`.`DEUDA_INTERES`),2) AS `round(sum(t.DEUDA_INTERES),2)`,round(sum(`t`.`DEUDA_IVA`),2) AS `round(sum(t.DEUDA_IVA),2)`,round(sum(`t`.`DEUDA_TOTAL`),2) AS `round(sum(t.DEUDA_TOTAL),2)`,round(sum(`t`.`CARGO_INCOB`),2) AS `round(sum(t.CARGO_INCOB),2)` from `vw_tablon` `t` where (`t`.`DEUDA_TOTAL` <> 0) group by `t`.`NOMBRE_PRODUCTO` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_costo_prestamos`
--

/*!50001 DROP VIEW IF EXISTS `vw_costo_prestamos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_costo_prestamos` AS select `c`.`PERIODO` AS `PERIODO`,`v`.`N_PRESTAMO` AS `N_PRESTAMO`,`p`.`NOMBRE_PRODUCTO` AS `NOMBRE_PRODUCTO`,sum(`c`.`PCIO_PROM_UNIT`) AS `COSTO` from ((`ventas` `v` left join `costos` `c` on(((`v`.`PRODUCTO_ID` = `c`.`PRODUCTO_ID`) and (`c`.`PERIODO` = concat(year(`v`.`FECHA_LIQUIDACION`),if((length(month(`v`.`FECHA_LIQUIDACION`)) = 1),concat('0',month(`v`.`FECHA_LIQUIDACION`)),month(`v`.`FECHA_LIQUIDACION`))))))) left join `producto` `p` on((`p`.`PRODUCTO_ID` = `c`.`PRODUCTO_ID`))) group by `v`.`N_PRESTAMO`,`c`.`PERIODO`,`p`.`NOMBRE_PRODUCTO` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_tablon`
--

/*!50001 DROP VIEW IF EXISTS `vw_tablon`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_tablon` AS select distinct curdate() AS `FECHA_PROCESO`,`v`.`N_PRESTAMO` AS `N_PRESTAMO`,`p`.`NOMBRE_PRODUCTO` AS `NOMBRE_PRODUCTO`,`v`.`FECHA_LIQUIDACION` AS `FECHA_LIQUIDACION`,`v`.`PLAZO` AS `PLAZO`,`v`.`TNA` AS `TNA`,`v`.`CAP_FINANCIADO` AS `CAP_FINANCIADO`,`d`.`DEUDA_CAPITAL` AS `DEUDA_CAPITAL`,`d`.`DEUDA_INTERES` AS `DEUDA_INTERES`,`d`.`DEUDA_IVA` AS `DEUDA_IVA`,`d`.`DEUDA_TOTAL` AS `DEUDA_TOTAL`,`v`.`ATRASO` AS `ATRASO`,round((`d`.`DEUDA_TOTAL` * `i`.`PORCENT_INCOB`),2) AS `CARGO_INCOB`,`c`.`PERIODO` AS `PERIODO_COSTO`,`c`.`COSTO` AS `COSTO` from ((((`ventas` `v` left join `vw_costo_prestamos` `c` on((`c`.`N_PRESTAMO` = `v`.`N_PRESTAMO`))) left join `deuda` `d` on((`c`.`N_PRESTAMO` = `v`.`N_PRESTAMO`))) left join `incobrabilidad` `i` on((`v`.`ATRASO` = `v`.`ATRASO`))) left join `producto` `p` on((`p`.`PRODUCTO_ID` = `v`.`PRODUCTO_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_int_devengado`
--

/*!50001 DROP VIEW IF EXISTS `vw_int_devengado`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_int_devengado` AS select curdate() AS `FECHA_PROCESO`,`c`.`N_PRESTAMO` AS `N_PRESTAMO`,`c`.`N_CUOTA` AS `N_CUOTA`,(`c`.`F_VTO` + interval -(1) month) AS `F_INICIO`,`c`.`F_VTO` AS `F_VTO`,`p`.`F_PAGO` AS `F_PAGO`,`c`.`CAPITAL` AS `CAPITAL`,(case when (curdate() > `c`.`F_VTO`) then round(`c`.`INTERES`,2) when (curdate() > `p`.`F_PAGO`) then round(`c`.`INTERES`,2) when (curdate() < (`c`.`F_VTO` + interval -(1) month)) then 0 else round(((`c`.`INTERES` / (to_days(`c`.`F_VTO`) - to_days((`c`.`F_VTO` + interval -(1) month)))) * (to_days(curdate()) - to_days((`c`.`F_VTO` + interval -(1) month)))),2) end) AS `INT_DEV`,(case when (curdate() > `c`.`F_VTO`) then round(`c`.`IVA`,2) when (curdate() > `p`.`F_PAGO`) then round(`c`.`IVA`,2) else 0 end) AS `IVA_DEV`,(case when (`p`.`F_PAGO` is not null) then 'CANCELADA' when (curdate() > `c`.`F_VTO`) then 'VENCIDA' when (curdate() < (`c`.`F_VTO` + interval -(1) month)) then 'NO VIGENTE' else 'VIGENTE' end) AS `ESTADO_CUOTA`,(case when (`p`.`F_PAGO` is not null) then 0 when (curdate() > `c`.`F_VTO`) then (to_days(curdate()) - to_days(`c`.`F_VTO`)) else 0 end) AS `ATRASO_CUOTA` from (`caida_prestamos` `c` left join `vw_detalle_pagos` `p` on(((`p`.`N_PRESTAMO` = `c`.`N_PRESTAMO`) and (`p`.`N_CUOTA` = `c`.`N_CUOTA`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_detalle_pagos`
--

/*!50001 DROP VIEW IF EXISTS `vw_detalle_pagos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_detalle_pagos` AS select `c`.`N_PRESTAMO` AS `N_PRESTAMO`,`c`.`N_CUOTA` AS `N_CUOTA`,`c`.`F_VTO` AS `F_VTO`,`c`.`CAPITAL` AS `CAPITAL`,`c`.`INTERES` AS `INTERES`,`c`.`IVA` AS `IVA`,`p`.`F_PAGO` AS `F_PAGO`,`p`.`IMPORTE` AS `IMPORTE` from (`caida_prestamos` `c` join `pagos` `p` on(((`p`.`N_PRESTAMO` = `c`.`N_PRESTAMO`) and (`p`.`N_CUOTA` = `c`.`N_CUOTA`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'ent_fciera'
--

--
-- Dumping routines for database 'ent_fciera'
--
/*!50003 DROP FUNCTION IF EXISTS `COSTO_POR_PERIODO` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `COSTO_POR_PERIODO`(PERIODO int) RETURNS decimal(20,2)
    DETERMINISTIC
begin
declare TOTAL decimal(20,2);
select sum(COSTO) into TOTAL
from vw_costo_prestamos where PERIODO=PERIODO;
return TOTAL;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `TOTAL_VENTAS` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `TOTAL_VENTAS`(PRODUCTO_ID int, PERIODO int) RETURNS decimal(20,2)
    DETERMINISTIC
begin
declare TOTAL decimal(20,2);
select sum(CAP_FINANCIADO) into TOTAL
from ventas where PRODUCTO_ID=PRODUCTO_ID
and PERIODO=concat(year(FECHA_LIQUIDACION),if(length(month(FECHA_LIQUIDACION))=1,concat('0',month(FECHA_LIQUIDACION)),month(FECHA_LIQUIDACION)));
return TOTAL;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `01-ACT_F_VTA_TABLA_VTA` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `01-ACT_F_VTA_TABLA_VTA`()
BEGIN
create temporary table TEMP_PROX_VTO 
	Select
    c.N_PRESTAMO,
    min(c.F_VTO) as PROX_VTO
    from caida_prestamos c
    where  concat(c.N_PRESTAMO,'_',c.N_CUOTA) not in (select concat(p.N_PRESTAMO,'_',p.N_CUOTA) from pagos p)
    group by (c.N_PRESTAMO);
    
    update ventas v, TEMP_PROX_VTO p
    set v.F_ULT_VTO_IMPAGO=p.PROX_VTO 
    where v.N_PRESTAMO=P.N_PRESTAMO;

    drop temporary table if exists TEMP_PROX_VTO;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `02-ACT_ATR_TABLA_VENTAS` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `02-ACT_ATR_TABLA_VENTAS`()
BEGIN

drop temporary table if exists TEMP_ATRASO;

create temporary table TEMP_ATRASO
	Select
    V.N_PRESTAMO,
    IF(datediff(curdate(),v.F_ULT_VTO_IMPAGO)<0,0,datediff(curdate(),v.F_ULT_VTO_IMPAGO)) AS ATR
    from ventas v;
    
update ventas v, TEMP_ATRASO a
    set v.atraso=a.atr
    where v.N_PRESTAMO=a.N_PRESTAMO;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `03-TABLA_DEUDA` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `03-TABLA_DEUDA`()
BEGIN
drop table if exists DEUDA;
create table DEUDA 
select
curdate() as FECHA_PROCESO,
d.N_PRESTAMO,
round(SUM(d.CAPITAL),2) AS DEUDA_CAPITAL,
round(SUM(d.INT_DEV),2) AS DEUDA_INTERES,
round(SUM(d.IVA_DEV),2) AS DEUDA_IVA,
round(SUM(d.CAPITAL) + SUM(d.INT_DEV) + SUM(d.IVA_DEV),2) AS DEUDA_TOTAL
from VW_INT_DEVENGADO d
where d.ESTADO_CUOTA!='CANCELADA'
group by d.N_PRESTAMO;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-02  4:05:22
